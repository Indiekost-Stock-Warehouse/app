### INFO
* Asset/Image buat taro Icon atau gambar yang mau di pakai
* UI/UX Source UI yang belum di merge ke main.py atau belum siap
* file db jgn di pindah 
